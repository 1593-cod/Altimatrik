package com.altimatrik.orderfood.api;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.altimatrik.orderfood.model.Order;
import com.altimatrik.orderfood.service.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/")
@Api(value = "Order Service API Details", description = "Used to maintain the orders and the details" )
public class OrderRestApi {
    OrderService orderService;

    @Autowired
    public OrderRestApi(OrderService orderService) {
        this.orderService = orderService;
    }

    
    @ApiOperation(value = "Connectivity Check", notes = "Result should be ---  Success!!!")
	@RequestMapping(value = "/orders/test", method = {RequestMethod.GET})
	@CrossOrigin
	public String getStatus()
	{
		return "Success!!!";
	}
    
    
    @RequestMapping(value = "/orders", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
    @ApiOperation(value = "Create New Order", notes = "")
    public Order createOder(@RequestBody Order order) {
        return orderService.createOrder(order);
    }
}
