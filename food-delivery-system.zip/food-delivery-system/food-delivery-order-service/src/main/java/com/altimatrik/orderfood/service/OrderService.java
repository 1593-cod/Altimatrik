package com.altimatrik.orderfood.service;

import com.altimatrik.orderfood.model.Order;

public interface OrderService {
    Order createOrder(Order order);
}
