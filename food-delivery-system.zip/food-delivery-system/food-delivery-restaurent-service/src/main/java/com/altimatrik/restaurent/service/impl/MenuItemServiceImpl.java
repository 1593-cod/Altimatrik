package com.altimatrik.restaurent.service.impl;

import java.util.Arrays;

import org.dozer.DozerBeanMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimatrik.restaurent.model.MenuItemDto;
import com.altimatrik.restaurent.repo.model.MenuItem;
import com.altimatrik.restaurent.repo.model.Restaurant;
import com.altimatrik.restaurent.repository.MenuItemRepository;
import com.altimatrik.restaurent.service.MenuItemService;

import java.util.List;

@Service
public class MenuItemServiceImpl implements MenuItemService {

	@Autowired
	private MenuItemRepository menuItemRepository;

	@Override
	public List<MenuItem> findAllByRestaurantId(String rid) {
		return menuItemRepository.findAllByRestaurantId(rid);
	}

	/*
	 * @Override public void createMenuItem(MenuItem menuItem) {
	 * menuItemRepository.save(menuItem); }
	 */

	@Override
	public void uploadMenuItems(List<MenuItem> menuItems) {
		menuItemRepository.saveAll(menuItems);
	}

	public void createMenuItem(MenuItemDto menuItemDto) {

		MenuItem menuItem = createDomainObj(menuItemDto);
		menuItemRepository.save(menuItem);
	}

	private MenuItem createDomainObj(MenuItemDto menuItemDto) {
		MenuItem menuItem = new MenuItem();
		Restaurant restaurant = new Restaurant();
		restaurant.setId(menuItemDto.getRestaurantId());
		menuItem.setDescription(menuItemDto.getMenuDescription());
		menuItem.setId(menuItemDto.getMenuId());
		menuItem.setName(menuItemDto.getMenuName());
		menuItem.setPrice(menuItemDto.getPrice());
		menuItem.setRestaurant(restaurant);
		/*
		DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
		dozerBeanMapper.setMappingFiles(Arrays.asList("mappings\\menuitem.xml"));
		menuItem = dozerBeanMapper.map(menuItemDto, MenuItem.class);
		*/
		return menuItem;
	}
}
