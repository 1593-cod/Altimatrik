package com.altimatrik.restaurent.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimatrik.restaurent.repo.model.Restaurant;
import com.altimatrik.restaurent.repository.RestaurantRepository;
import com.altimatrik.restaurent.service.RestaurantService;

@Service

public class RestaurantServiceImpl implements RestaurantService {
	
	@Autowired
    private RestaurantRepository restaurantRepository;

	/*
	 * @Autowired public RestaurantServiceImpl(RestaurantRepository
	 * restaurantRepository) { this.restaurantRepository = restaurantRepository; }
	 */

    @Override
    public void createRestaurant(Restaurant restaurant) {
        restaurantRepository.save(restaurant);
    }

    @Override
    public Restaurant getRestaurantByName(String name) {
        Restaurant restaurant = restaurantRepository.findFirstByName(name);
        return restaurant;
    }
}
