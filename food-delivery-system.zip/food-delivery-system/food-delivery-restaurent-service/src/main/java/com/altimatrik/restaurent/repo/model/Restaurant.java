package com.altimatrik.restaurent.repo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//import org.hibernate.annotations.Entity;
//import org.springframework.data.annotation.Id;
//import org.springframework.data.annotation.PersistenceConstructor;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name="TBL_RESTAURANT")
public class Restaurant implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @Column(nullable = false, name = "Restaurant_ID")
    private String id;

    @Column(nullable = false, name = "NAME")
    private String name;

    @Column(nullable = false, name = "LOCATION")
    private String location;
    
    @Column(nullable = false, name = "RATING")
    private int rating;
    
	/*
	 * @OneToMany(mappedBy="restaurant")
	 * 
	 * @JsonIgnore private Set<MenuItem> menuItems;
	 */
    
   
    @JsonIgnore
    @JsonManagedReference
    @OneToOne(mappedBy = "restaurant", cascade = CascadeType.ALL)
    private MenuItem menuItem;

    
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	
	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public MenuItem getMenuItem() {
		return menuItem;
	}

	public void setMenuItem(MenuItem menuItem) {
		this.menuItem = menuItem;
	}

}
