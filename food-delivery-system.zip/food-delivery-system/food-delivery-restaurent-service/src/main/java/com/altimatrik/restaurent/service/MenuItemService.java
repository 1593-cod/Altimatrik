package com.altimatrik.restaurent.service;




import java.util.List;

import com.altimatrik.restaurent.model.MenuItemDto;
import com.altimatrik.restaurent.repo.model.MenuItem;

public interface MenuItemService {
    List<MenuItem> findAllByRestaurantId(String rid);
    void createMenuItem(MenuItemDto menuItemDto);
    void uploadMenuItems(List<MenuItem> menuItems);
}
