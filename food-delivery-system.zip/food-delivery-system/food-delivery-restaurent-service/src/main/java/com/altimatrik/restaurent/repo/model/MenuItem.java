package com.altimatrik.restaurent.repo.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

//import org.hibernate.annotations.Entity;
//import org.springframework.data.annotation.Id;


//@JsonPropertyOrder({"id","name","description","price"})
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name="TBL_MENU_ITEM")
public class MenuItem implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @Column(nullable = false, name = "MENU_ID")
    private String id;

    @Column(nullable = false, name = "MENU_NAME")
    private String name;
    
    @Column(nullable = true, name = "DESC")
    private String description;
    
    @Column(nullable = false, name = "PRICE")
    private BigDecimal price;
    

    @OneToOne
    @JoinColumn(name ="Restaurant_ID", referencedColumnName = "Restaurant_ID", unique = false)
    private Restaurant restaurant;


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public BigDecimal getPrice() {
		return price;
	}


	public void setPrice(BigDecimal price) {
		this.price = price;
	}


	public Restaurant getRestaurant() {
		return restaurant;
	}


	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
    
	
	
    
    
}
