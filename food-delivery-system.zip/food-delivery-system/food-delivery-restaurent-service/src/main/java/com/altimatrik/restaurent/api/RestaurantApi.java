package com.altimatrik.restaurent.api;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.altimatrik.restaurent.model.MenuItemDto;
import com.altimatrik.restaurent.repo.model.MenuItem;
import com.altimatrik.restaurent.repo.model.Restaurant;
import com.altimatrik.restaurent.service.MenuItemService;
import com.altimatrik.restaurent.service.RestaurantService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;

@RestController
@RequestMapping("/")
@Api(value = "Restaurant Details", description = "Used to maintain the resaturent details and their menu items" )
public class RestaurantApi 
{
	@Autowired
    private RestaurantService restaurantService;
	
	@Autowired
    private MenuItemService menuItemService;

    

	@CrossOrigin
    @RequestMapping(value = "/restaurants", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
    @ApiOperation(value = "Create New Restaurent", notes = "Result should be ---  Success!!!")
    public void createRestaurant(@RequestBody Restaurant restaurant) {
        restaurantService.createRestaurant(restaurant);
    }

	@CrossOrigin
    @RequestMapping(value = "/restaurants", method = RequestMethod.GET)
    @ApiOperation(value = "Search Restaurent by Name")
    public ResponseEntity<?> findRestaurant(@RequestParam(value = "name") String name) {
    	Restaurant restaurant = restaurantService.getRestaurantByName(name);
    	
    	if(restaurant != null)
    		return new ResponseEntity<Restaurant>(restaurant, HttpStatus.OK);
    	
    	return new ResponseEntity<Object>(HttpStatus.NOT_FOUND);
    }

	/*
	@CrossOrigin
    @RequestMapping(value = "/restaurants/menuItems", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
	@ApiOperation(value = "Create MenuItem/Catalogue for Particular Restaurent one by one")
    public void createMenuItem(@RequestBody MenuItem menuItem) {
        menuItemService.createMenuItem(menuItem);
    }
	*/
	
	@CrossOrigin
    @RequestMapping(value = "/restaurants/menuItems", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
	@ApiOperation(value = "Create MenuItem/Catalogue for Particular Restaurent one by one")
    public void createMenuItem(@RequestBody MenuItemDto menuItemDto) {
        menuItemService.createMenuItem(menuItemDto);
    }
	
	@CrossOrigin
    @RequestMapping(value = "/restaurants/{rid}/menuItems", method = RequestMethod.GET)
	@ApiOperation(value = "List MenuItems/Catalogue from Particular Restaurent")
    public ResponseEntity<?> getMenuItems(@PathVariable String rid) {
    	
    	List<MenuItem> menuItems = menuItemService.findAllByRestaurantId(rid);
    	
    	if(menuItems != null && menuItems.size() > 0)
    		return new ResponseEntity<List<MenuItem>>(menuItems, HttpStatus.OK);
    	
    	return new ResponseEntity<Object>(HttpStatus.NOT_FOUND);
    }

	
    @RequestMapping(value = "/restaurants/bulk/menuItems", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "Bulk upload - MenuItem/Catalogue for Particular Restaurent")
    public void upload(@RequestBody List<MenuItem> menuItems) {
        this.menuItemService.uploadMenuItems(menuItems);
    }
}
