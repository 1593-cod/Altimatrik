package com.altimatrik.restaurent.service;

import com.altimatrik.restaurent.repo.model.Restaurant;

public interface RestaurantService {
    void createRestaurant(Restaurant restaurant);
    Restaurant getRestaurantByName(String name);
}
