package com.altimatrik.restaurent.api;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "ConnectivityTest", description = "Used for Connectivity testing.." )

public class Test {
	

	@ApiOperation(value = "Connectivity Check", notes = "Result should be ---  Success!!!")
	@RequestMapping(value = "/", method = {RequestMethod.GET})
	@CrossOrigin
	public String getStatus()
	{
		return "Success!!!";
	}
	/*public ResponseEntity<List<com.rest.model.Employee>> getAllEmployess()
	 {
		 List<com.rest.model.Employee> listEmployee = employees.getAllEmployees();
		 
		 return new ResponseEntity<List<com.rest.model.Employee>>(listEmployee, HttpStatus.OK);
	 }*/

}
